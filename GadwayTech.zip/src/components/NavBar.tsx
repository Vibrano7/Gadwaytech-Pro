import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const NavBar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-gray-900/95 backdrop-blur-sm' : 'bg-transparent'
    }`}>
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          <div className="flex-shrink-0">
            <span className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-200 bg-clip-text text-transparent">
              Gadway Tech
            </span>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-8">
              <a href="#" className="text-white hover:text-blue-400 transition-colors">Home</a>
              <a href="#" className="text-white hover:text-blue-400 transition-colors">Services</a>
              <a href="#" className="text-white hover:text-blue-400 transition-colors">About</a>
              <a href="#" className="text-white hover:text-blue-400 transition-colors">Portfolio</a>
              <a href="#" className="text-white hover:text-blue-400 transition-colors">Contact</a>
              <button className="bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 transition-all duration-300 transform hover:scale-105">
                Get Started
              </button>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-white hover:text-blue-400 transition-colors"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1">
              <a href="#" className="block px-3 py-2 text-white hover:text-blue-400 transition-colors">Home</a>
              <a href="#" className="block px-3 py-2 text-white hover:text-blue-400 transition-colors">Services</a>
              <a href="#" className="block px-3 py-2 text-white hover:text-blue-400 transition-colors">About</a>
              <a href="#" className="block px-3 py-2 text-white hover:text-blue-400 transition-colors">Portfolio</a>
              <a href="#" className="block px-3 py-2 text-white hover:text-blue-400 transition-colors">Contact</a>
              <button className="w-full mt-4 bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 transition-all duration-300">
                Get Started
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default NavBar;